Rails.application.routes.draw do
  devise_for :models
  resources :attachments
  resources :mails
  resources :sauces
  resources :kebabs
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
