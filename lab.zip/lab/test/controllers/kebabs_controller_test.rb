require 'test_helper'

class KebabsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @kebab = kebabs(:one)
  end

  test "should get index" do
    get kebabs_url
    assert_response :success
  end

  test "should get new" do
    get new_kebab_url
    assert_response :success
  end

  test "should create kebab" do
    assert_difference('Kebab.count') do
      post kebabs_url, params: { kebab: { price: @kebab.price, sauce: @kebab.sauce, size: @kebab.size } }
    end

    assert_redirected_to kebab_url(Kebab.last)
  end

  test "should show kebab" do
    get kebab_url(@kebab)
    assert_response :success
  end

  test "should get edit" do
    get edit_kebab_url(@kebab)
    assert_response :success
  end

  test "should update kebab" do
    patch kebab_url(@kebab), params: { kebab: { price: @kebab.price, sauce: @kebab.sauce, size: @kebab.size } }
    assert_redirected_to kebab_url(@kebab)
  end

  test "should destroy kebab" do
    assert_difference('Kebab.count', -1) do
      delete kebab_url(@kebab)
    end

    assert_redirected_to kebabs_url
  end
end
