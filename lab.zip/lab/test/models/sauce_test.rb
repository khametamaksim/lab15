require 'test_helper'

class SauceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
