require "application_system_test_case"

class KebabsTest < ApplicationSystemTestCase
  setup do
    @kebab = kebabs(:one)
  end

  test "visiting the index" do
    visit kebabs_url
    assert_selector "h1", text: "Kebabs"
  end

  test "creating a Kebab" do
    visit kebabs_url
    click_on "New Kebab"

    fill_in "Price", with: @kebab.price
    fill_in "Sauce", with: @kebab.sauce
    fill_in "Size", with: @kebab.size
    click_on "Create Kebab"

    assert_text "Kebab was successfully created"
    click_on "Back"
  end

  test "updating a Kebab" do
    visit kebabs_url
    click_on "Edit", match: :first

    fill_in "Price", with: @kebab.price
    fill_in "Sauce", with: @kebab.sauce
    fill_in "Size", with: @kebab.size
    click_on "Update Kebab"

    assert_text "Kebab was successfully updated"
    click_on "Back"
  end

  test "destroying a Kebab" do
    visit kebabs_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Kebab was successfully destroyed"
  end
end
