class CreateKebabs < ActiveRecord::Migration[5.2]
  def change
    create_table :kebabs do |t|
      t.string :size
      t.integer :price
      t.string :sauce

      t.timestamps
    end
  end
end
