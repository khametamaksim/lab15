class Sauce < ApplicationRecord
end
