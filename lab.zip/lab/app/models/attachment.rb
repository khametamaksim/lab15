class Attachment < ApplicationRecord
    belongs_to:mail
end
