class Kebab < ApplicationRecord
end
