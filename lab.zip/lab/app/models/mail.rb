class Mail < ApplicationRecord
    has_many:attachments
end
