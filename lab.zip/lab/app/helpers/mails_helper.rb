module MailsHelper
end
